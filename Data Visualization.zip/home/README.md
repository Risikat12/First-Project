# Ford Bike Trip Data 
## by Ibrahim Risikat


## Dataset

> The name of the dataset I will be working on is Ford Bike trip data. The dataset I will be working on is a dataset that includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area. The Dataset consists of information regarding 126778 bike trips, including its timing and geolocation of the start and end of each trip. 
For the wrangling, I dropped some columns that I wont be using for the analysis. These are the start_station_latitude, start_station_longitude, end_station_latitude, and end_station_longitude. 
I converted the user type and member gender to category datatype. I also converted the start time and end time to datetime datatype. From the state time column, I was able to extrapolate a new column containing the hours, start and month. This information will be useful in my analysis. I converted duration sec column to minutes and added another column and named it duration min for easier analysis. The information gotten from each member birth year was used to get the age of each member for the ride. 

## Summary of Findings

> To get an insight for the analysis, the different data provided was analysed. Quantitative and categorical data to we use to create insight for the analysis. From the charts, It could be seen that most of the bike trips lasts for about 4 to 18 minutes. There are not a lot of bike trips that lasted less than 3 minutes and over 40 minutes. Ford Bike service is mostly used on Wednesday with over 25,000 users. The usage decreases on the weekends and no ride on Sunday. Most of the trips are done by subscribers. The Male gender take the bike more than female gender with over 80,000 males using the service. The Males having a shorted trip than the female and other gender.From the charts, We it was discovered that majority of people that take the bike trip are between 29 and 39years.
It can be deduced that Customers have more ride duration than subscribers. Subcribers are much younger than the customers. It was discovered that the younger age group didnt share their ride but the higher age group shared their ride. Comparing the gender types as it relates to trip duration, the age 20 to 40 represents the group have the most ride. The hour of the day and the day of the week became clearer in this findings. Most subcribers do have most of their ride during the week than weekend. While for the customers, Most of their rides are during the weekday and a few ride during the weekend.



## Key Insights for Presentation

> The higher ride frequencies for the morning (8th and 9th hrs) and evening (5pm and 6pm) can be linked to rush hours where people leave for work and come back later in the evening. Customer user type trips take a longer duration compared to subscriber user type. Weekend trips take a longer duration as compared to trips taken during the week.